<!-- wraps page and content -->
    <div id="main-wrapper" class="main-wrapper">

    <!-- sidebar section  -->
      <div id="side-border" class="sidebar">
        <div id="branding-section" class="branding-section">

        <!-- sidebar elements -->

          <div id="sidebar-elements">
            <!-- logo -->
            <div class="logo">

            </div>
          </div>

          <div id="sidebar-elements" class="title">
              <div class="directory-wrapper">
                  <h2 id="directory-text">SOSNA</h2>
                  <h2 id="directory-text">NEIGHBORHOOD</h2>
                  <h2 id="directory-text">DIRECTORY</h2>
              </div>
          </div>

        </div>

        <!-- sidebar divider -->
        <div class="sidebar-divider">

        </div>

        <!-- link section -->
        <div id="link-section" class="link-section">
          <div class="text-wrapper">
            <h4>FIND A BUSSINESS/ORGANIZATION</h4>
            <h4>SEARCH BY ACTIVITY</h4>
            <h4>VIEW FULL MAP</h4>
          </div>
        </div>

        <!-- sidebar divders -->
        <div class="sidebar-divider">

        </div>

        <!-- redirect section -->
        <div id="addition-link-section" class="addition-link-section">

          <div class="text-wrapper">
            <div class="">
              <h4>About</h4>
            </div>
            <div class="">
              <h4>Sponsor</h4>
            </div>
            <div class="">
              <h4>Advertising</h4>
            </div>
            <div class="">
              <h4>Add Bussiness</h4>
            </div>
          </div>

        </div>
      </div>

    <!-- divider -->
      <div id="divder" class="divider">
      </div>
